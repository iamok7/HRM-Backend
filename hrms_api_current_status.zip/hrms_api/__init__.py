import os
import click
from flask import Flask
from flask_cors import CORS

from hrms_api.extensions import db
from hrms_api.common.errors import register_error_handlers
from hrms_api.models import load_all


from datetime import timedelta, datetime
from flask_jwt_extended import JWTManager

jwt = JWTManager()

def create_app():
    app = Flask(__name__)

    # Config
    app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "dev-jwt-secret")
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=30)
    app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=7)
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg2://postgres:4445@127.0.0.1:5432/hrms_dev",
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # CORS (dev)
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    # Extensions
    db.init_app(app)
    register_error_handlers(app)
    jwt.init_app(app)

    # Ensure models are loaded so metadata is complete
    with app.app_context():
        load_all()

    # Blueprints
    from hrms_api.blueprints.health import bp as health_bp
    from hrms_api.blueprints.auth import bp as auth_bp
    from hrms_api.blueprints.users import bp as users_bp
    from hrms_api.blueprints.master_companies import bp as companies_bp
    from hrms_api.blueprints.master_locations import bp as locations_bp
    from hrms_api.blueprints.master_departments import bp as departments_bp
    from hrms_api.blueprints.master_designations import bp as designations_bp
    from hrms_api.blueprints.master_grades import bp as grades_bp
    from hrms_api.blueprints.master_cost_centers import bp as cost_centers_bp
    from hrms_api.blueprints.auth_v1 import bp as auth_v1_bp
    from hrms_api.blueprints.employees import bp as employees_bp
    from hrms_api.blueprints.employee_extras import bp as employee_extras_bp
    from hrms_api.blueprints.attendance_masters import bp as attendance_bp
    from hrms_api.blueprints.attendance_assignments import bp as attendance_assignments_bp
    from hrms_api.blueprints.attendance_calendar import bp as attendance_calendar_bp
    from hrms_api.blueprints.attendance_punches import bp as attendance_punches_bp

    app.register_blueprint(health_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(companies_bp)
    app.register_blueprint(locations_bp)
    app.register_blueprint(departments_bp)
    app.register_blueprint(designations_bp)
    app.register_blueprint(grades_bp)
    app.register_blueprint(cost_centers_bp)
    app.register_blueprint(auth_v1_bp)
    app.register_blueprint(employees_bp)
    app.register_blueprint(employee_extras_bp)
    app.register_blueprint(attendance_bp)
    app.register_blueprint(attendance_assignments_bp)
    app.register_blueprint(attendance_calendar_bp)
    app.register_blueprint(attendance_punches_bp)

    # ---- CLI (registered on this app instance) ----
    @app.cli.command("seed-core")
    def seed_core():
        """Seed demo company and admin user."""
        from hrms_api.models.user import User
        from hrms_api.models.master import Company

        c = Company.query.filter_by(code="DEMO").first()
        if not c:
            c = Company(code="DEMO", name="Demo Co")
            db.session.add(c)
            db.session.commit()

        u = User.query.filter_by(email="admin@demo.local").first()
        if not u:
            u = User(email="admin@demo.local", full_name="Demo Admin")
            u.set_password("4445")
            db.session.add(u)
            db.session.commit()

        click.echo("Seeded: company DEMO, user admin@demo.local / 4445")

    @app.cli.command("seed-masters")
    def seed_masters():
        """Seed sample locations under DEMO company."""
        from hrms_api.models.master import Company, Location
        c = Company.query.filter_by(code="DEMO").first()
        if not c:
            click.echo("Run flask seed-core first (creates DEMO company).")
            return
        for nm in ("Pune", "Mumbai"):
            if not c.locations.filter_by(name=nm).first():
                db.session.add(Location(company_id=c.id, name=nm))
        db.session.commit()
        click.echo("Seeded locations: Pune, Mumbai")

    @app.cli.command("seed-more-masters")
    def seed_more_masters():
        from hrms_api.models.master import Company, Department, Designation, Grade, CostCenter
        c = Company.query.filter_by(code="DEMO").first()
        if not c:
            click.echo("Run flask seed-core first."); return
        # Departments
        d_eng = c.departments.filter_by(name="Engineering").first()
        if not d_eng:
            d_eng = Department(company_id=c.id, name="Engineering"); db.session.add(d_eng)
        d_hr = c.departments.filter_by(name="HR").first()
        if not d_hr:
            d_hr = Department(company_id=c.id, name="HR"); db.session.add(d_hr)
        db.session.commit()
        # Designations
        if not d_eng.designations.filter_by(name="Software Engineer").first():
            db.session.add(Designation(department_id=d_eng.id, name="Software Engineer"))
        if not d_hr.designations.filter_by(name="HR Executive").first():
            db.session.add(Designation(department_id=d_hr.id, name="HR Executive"))
        # Grades
        for g in ("G1","G2","G3"):
            if not Grade.query.filter_by(name=g).first():
                db.session.add(Grade(name=g))
        # Cost centers
        for code, name in (("CC-001","Corporate"),("CC-ENG","Engineering"),("CC-HR","Human Resources")):
            if not CostCenter.query.filter_by(code=code).first():
                db.session.add(CostCenter(code=code, name=name))
        db.session.commit()
        click.echo("Seeded: departments, designations, grades, cost centers.")

    @app.cli.command("seed-auth")
    def seed_auth():
        """Create 'admin' role and assign to admin@demo.local user."""
        from hrms_api.models.security import Role, UserRole
        from hrms_api.models.user import User
        admin = Role.query.filter_by(code="admin").first()
        if not admin:
            admin = Role(code="admin"); db.session.add(admin); db.session.commit()
        u = User.query.filter_by(email="admin@demo.local").first()
        if not u:
            click.echo("User admin@demo.local not found. Run flask seed-core first."); return
        link = UserRole.query.filter_by(user_id=u.id, role_id=admin.id).first()
        if not link:
            db.session.add(UserRole(user_id=u.id, role_id=admin.id)); db.session.commit()
        click.echo("Seeded role 'admin' and linked to admin@demo.local")

    @app.cli.command("seed-employees")
    def seed_employees():
        from hrms_api.models.master import Company, Location, Department, Designation, Grade, CostCenter
        from hrms_api.models.employee import Employee
        c = Company.query.filter_by(code="DEMO").first()
        if not c:
            click.echo("Company DEMO missing. Run seed-core."); return
        loc = Location.query.filter_by(company_id=c.id, name="Pune").first()
        dept = Department.query.filter_by(company_id=c.id, name="Engineering").first()
        des  = Designation.query.filter_by(name="Software Engineer").first()
        grd  = Grade.query.filter_by(name="G1").first()
        cc   = CostCenter.query.filter_by(code="CC-ENG").first()
        if not Employee.query.filter_by(email="emp1@demo.local").first():
            e = Employee(company_id=c.id, location_id=loc.id if loc else None,
                        department_id=dept.id if dept else None, designation_id=des.id if des else None,
                        grade_id=grd.id if grd else None, cost_center_id=cc.id if cc else None,
                        code="E-0001", email="emp1@demo.local", first_name="Demo", last_name="User",
                        doj=datetime.utcnow().date(), employment_type="fulltime", status="active")
            db.session.add(e); db.session.commit()
        click.echo("Seeded employee emp1@demo.local (E-0001)")




    return app
