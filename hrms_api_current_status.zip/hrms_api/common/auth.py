from functools import wraps
from flask_jwt_extended import jwt_required, get_jwt
from hrms_api.common.http import fail

def requires_roles(*codes):
    """
    Use on write routes to require at least one role from `codes`.
    Adds @jwt_required() automatically.
    """
    def outer(fn):
        @jwt_required()
        @wraps(fn)
        def inner(*args, **kwargs):
            claims = get_jwt() or {}
            roles = claims.get("roles", [])
            if not any(c in roles for c in codes):
                return fail("Forbidden", status=403)
            return fn(*args, **kwargs)
        return inner
    return outer
