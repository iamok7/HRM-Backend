from flask import Blueprint, jsonify, request
from hrms_api.extensions import db
from hrms_api.models.master import Company
from hrms_api.common.listing import get_page_limit, apply_q_search

bp = Blueprint("master_companies", __name__, url_prefix="/api/master/companies")

@bp.get("")
def companies_list():
    q = Company.query
    q = apply_q_search(q, Company.code, Company.name)
    page, limit = get_page_limit()
    total = q.count()
    items = q.order_by(Company.id.asc()).offset((page-1)*limit).limit(limit).all()
    return jsonify({
        "success": True,
        "data": [ _row(c) for c in items ],
        "meta": {"page": page, "limit": limit, "total": total}
    })

@bp.get("/<int:cid>")
def companies_get(cid: int):
    c = Company.query.get_or_404(cid)
    return jsonify({"success": True, "data": _row(c)})

@bp.post("")
def companies_create():
    data = request.get_json(force=True)
    code = (data.get("code") or "").strip()
    name = (data.get("name") or "").strip()
    if not code or not name:
        return jsonify({"success": False, "error": {"message":"code and name are required"}}), 422
    if Company.query.filter_by(code=code).first():
        return jsonify({"success": False, "error": {"message":"code already exists"}}), 409
    c = Company(code=code, name=name, is_active=bool(data.get("is_active", True)))
    db.session.add(c); db.session.commit()
    return jsonify({"success": True, "data": _row(c)}), 201

@bp.put("/<int:cid>")
def companies_update(cid: int):
    c = Company.query.get_or_404(cid)
    data = request.get_json(force=True)
    if "code" in data:
        new_code = (data["code"] or "").strip()
        if not new_code: return jsonify({"success": False, "error":{"message":"code cannot be empty"}}), 422
        if Company.query.filter(Company.id != cid, Company.code == new_code).first():
            return jsonify({"success": False, "error":{"message":"code already exists"}}), 409
        c.code = new_code
    if "name" in data:
        new_name = (data["name"] or "").strip()
        if not new_name: return jsonify({"success": False, "error":{"message":"name cannot be empty"}}), 422
        c.name = new_name
    if "is_active" in data:
        c.is_active = bool(data["is_active"])
    db.session.commit()
    return jsonify({"success": True, "data": _row(c)})

@bp.delete("/<int:cid>")
def companies_delete(cid: int):
    c = Company.query.get_or_404(cid)
    db.session.delete(c)
    db.session.commit()
    return jsonify({"success": True, "data": {"deleted": True, "id": cid}})

def _row(c: Company):
    return {
        "id": c.id,
        "code": c.code,
        "name": c.name,
        "is_active": c.is_active,
        "created_at": c.created_at.isoformat() if c.created_at else None,
    }
