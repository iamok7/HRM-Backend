from __future__ import annotations
from typing import Iterable, Dict, Any, Set

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from sqlalchemy import asc, desc, or_

# ✅ use relative imports to the package root (..), NOT single-dot
from ..extensions import db
from ..users import User

# Try to import your RBAC models; if names differ or file absent, fall back to None.
try:
    from ..security import Role, Permission, UserRole, RolePermission, UserPermission  # type: ignore
except Exception:
    Role = Permission = None  # type: ignore
    UserRole = RolePermission = UserPermission = None  # type: ignore

try:
    from ..common.auth import requires_perms, requires_roles
except Exception:
    def requires_perms(_):
        def _wrap(fn): return fn
        return _wrap
    def requires_roles(_):
        def _wrap(fn): return fn
        return _wrap


bp = Blueprint("security_admin", __name__, url_prefix="/api/v1/security")

# ---------- envelopes ----------
def _ok(data=None, status=200, **meta):
    payload = {"success": True, "data": data}
    if meta: payload["meta"] = meta
    return jsonify(payload), status

def _fail(msg, status=400, code=None, detail=None):
    err = {"message": msg}
    if code: err["code"] = code
    if detail: err["detail"] = detail
    return jsonify({"success": False, "error": err}), status

# ---------- helpers ----------
DEFAULT_PAGE, DEFAULT_SIZE, MAX_SIZE = 1, 20, 100

def _page_size():
    try:
        page = max(int(request.args.get("page", DEFAULT_PAGE)), 1)
    except Exception:
        page = DEFAULT_PAGE
    raw = request.args.get("size", request.args.get("limit", DEFAULT_SIZE))
    try:
        size = max(1, min(int(raw), MAX_SIZE))
    except Exception:
        size = DEFAULT_SIZE
    return page, size

def _sort_params(allowed: dict[str, object]):
    raw = (request.args.get("sort") or "").strip()
    out = []
    if not raw: return out
    for part in [p.strip() for p in raw.split(",") if p.strip()]:
        asc_order = True
        key = part
        if part.startswith("-"):
            asc_order = False
            key = part[1:]
        col = allowed.get(key)
        if col is not None:
            out.append((col, asc_order))
    return out

def _as_bool(val, field):
    if val is None: return None
    v = str(val).lower()
    if v in ("true","1","yes"):  return True
    if v in ("false","0","no"):  return False
    raise ValueError(f"{field} must be true/false")

def _user_row(u: Any, include_roles=False, include_perms=False, perm_cache: Dict[int, Set[str]] | None = None):
    row = {
        "id": u.id,
        "email": getattr(u, "email", None),
        "username": getattr(u, "username", None),
        "name": (
            (getattr(u, "first_name", "") or "")
            + ((" " + getattr(u, "last_name", "")) if getattr(u, "last_name", "") else "")
        ).strip() or getattr(u, "name", None),
        "is_active": getattr(u, "is_active", True),
    }
    if include_roles:
        roles = []
        if hasattr(u, "roles") and isinstance(u.roles, Iterable):
            roles = [getattr(r, "code", getattr(r, "name", None)) for r in u.roles]
        elif UserRole and Role:
            rs = (db.session.query(Role)
                  .join(UserRole, UserRole.role_id == Role.id)
                  .filter(UserRole.user_id == u.id).all())
            roles = [getattr(r, "code", getattr(r, "name", None)) for r in rs]
        row["roles"] = roles

    if include_perms:
        if perm_cache and u.id in perm_cache:
            row["permissions"] = sorted(list(perm_cache[u.id]))
        else:
            row["permissions"] = sorted(list(_effective_perms_for_user(u.id)))
    return row

def _effective_perms_for_user(user_id: int) -> Set[str]:
    perms: Set[str] = set()
    # Role-based
    if Role and RolePermission and UserRole and Permission:
        rp = (db.session.query(Permission.code)
              .join(RolePermission, RolePermission.permission_id == Permission.id)
              .join(Role, Role.id == RolePermission.role_id)
              .join(UserRole, UserRole.role_id == Role.id)
              .filter(UserRole.user_id == user_id).all())
        perms.update([c for (c,) in rp if c])
    # Direct user perms
    if UserPermission and Permission:
        up = (db.session.query(Permission.code)
              .join(UserPermission, UserPermission.permission_id == Permission.id)
              .filter(UserPermission.user_id == user_id).all())
        perms.update([c for (c,) in up if c])
    # Fallback if Permission uses name instead of code
    if not perms and Permission and hasattr(Permission, "name"):
        rp2 = (db.session.query(Permission.name)
               .join(RolePermission, RolePermission.permission_id == Permission.id)
               .join(Role, Role.id == RolePermission.role_id)
               .join(UserRole, UserRole.role_id == Role.id)
               .filter(UserRole.user_id == user_id).all())
        perms.update([c for (c,) in rp2 if c])
    return perms

def _roles_filter_clause(want_roles: set[str]):
    """Build OR filter for role code/name ∈ want_roles (case-insensitive)."""
    conds = []
    if not Role:
        return None
    for r in want_roles:
        if hasattr(Role, "code"):
            conds.append(db.func.lower(Role.code) == r)
        if hasattr(Role, "name"):
            conds.append(db.func.lower(Role.name) == r)
    if not conds:
        return None
    return or_(*conds)

# ============================================================================
# 1) List Manager/HR logins
#    GET /api/v1/security/staff?roles=manager,hr&q=&is_active=true|false&page=&size=&sort=name,-id
# ============================================================================
@bp.get("/staff")
@jwt_required()
@requires_perms("security.staff.read")
def list_staff():
    if not User:
        return _fail("User model not available", 500)

    want_roles = {r.strip().lower() for r in (request.args.get("roles") or "manager,hr").split(",") if r.strip()}

    q = User.query

    # Join + filter by roles if link tables exist
    if Role and UserRole:
        q = (q.join(UserRole, UserRole.user_id == User.id)
               .join(Role, Role.id == UserRole.role_id))
        clause = _roles_filter_clause(want_roles)
        if clause is not None:
            q = q.filter(clause)

    # text search
    s = (request.args.get("q") or "").strip()
    if s:
        like = f"%{s}%"
        parts = []
        for col in ("email", "username", "first_name", "last_name", "name"):
            if hasattr(User, col):
                parts.append(getattr(User, col).ilike(like))
        if parts:
            q = q.filter(or_(*parts))

    # is_active
    if "is_active" in request.args and hasattr(User, "is_active"):
        try:
            active = _as_bool(request.args.get("is_active"), "is_active")
        except Exception as ex:
            return _fail(str(ex), 422)
        if active is True:
            q = q.filter(User.is_active.is_(True))
        elif active is False:
            q = q.filter(User.is_active.is_(False))

    # sorting
    allowed = {
        "id": User.id,
        "name": getattr(User, "first_name", getattr(User, "name", User.id)),
        "email": getattr(User, "email", User.id),
        "username": getattr(User, "username", User.id),
        "created_at": getattr(User, "created_at", User.id),
    }
    for col, asc_order in _sort_params(allowed):
        q = q.order_by(asc(col) if asc_order else desc(col))
    if not request.args.get("sort"):
        q = q.order_by(asc(getattr(User, "first_name", getattr(User, "name", User.id))))

    # pagination
    page, size = _page_size()
    total = q.distinct().count()
    items = q.distinct().offset((page - 1) * size).limit(size).all()

    return _ok([_user_row(u, include_roles=True, include_perms=False) for u in items],
               page=page, size=size, total=total)

# ============================================================================
# 2) For Manager/HR: list all users with roles & effective permissions
#    GET /api/v1/security/users-permissions?q=&is_active=&page=&size=&sort=name
# ============================================================================
@bp.get("/users-permissions")
@jwt_required()
@requires_perms("security.perms.read")
@requires_roles("manager,hr")
def list_users_permissions():
    if not User:
        return _fail("User model not available", 500)

    q = User.query

    # search
    s = (request.args.get("q") or "").strip()
    if s:
        like = f"%{s}%"
        parts = []
        for col in ("email", "username", "first_name", "last_name", "name"):
            if hasattr(User, col):
                parts.append(getattr(User, col).ilike(like))
        if parts:
            q = q.filter(or_(*parts))

    # is_active
    if "is_active" in request.args and hasattr(User, "is_active"):
        try:
            active = _as_bool(request.args.get("is_active"), "is_active")
        except Exception as ex:
            return _fail(str(ex), 422)
        if active is True:
            q = q.filter(User.is_active.is_(True))
        elif active is False:
            q = q.filter(User.is_active.is_(False))

    # sorting
    allowed = {
        "id": User.id,
        "name": getattr(User, "first_name", getattr(User, "name", User.id)),
        "email": getattr(User, "email", User.id),
        "username": getattr(User, "username", User.id),
        "created_at": getattr(User, "created_at", User.id),
    }
    for col, asc_order in _sort_params(allowed):
        q = q.order_by(asc(col) if asc_order else desc(col))
    if not request.args.get("sort"):
        q = q.order_by(asc(getattr(User, "first_name", getattr(User, "name", User.id))))

    # paging
    page, size = _page_size()
    total = q.count()
    items = q.offset((page - 1) * size).limit(size).all()

    # precompute effective permissions for users in page
    perm_cache: Dict[int, Set[str]] = {}
    if items and Role and Permission:
        uids = [u.id for u in items]
        if UserRole and RolePermission:
            role_rows = (
                db.session.query(UserRole.user_id, Permission.code)
                .join(Role, Role.id == UserRole.role_id)
                .join(RolePermission, RolePermission.role_id == Role.id)
                .join(Permission, Permission.id == RolePermission.permission_id)
                .filter(UserRole.user_id.in_(uids))
                .all()
            )
            for uid, pcode in role_rows:
                if not pcode: continue
                perm_cache.setdefault(uid, set()).add(pcode)
        if UserPermission:
            user_rows = (
                db.session.query(UserPermission.user_id, Permission.code)
                .join(Permission, Permission.id == UserPermission.permission_id)
                .filter(UserPermission.user_id.in_(uids))
                .all()
            )
            for uid, pcode in user_rows:
                if not pcode: continue
                perm_cache.setdefault(uid, set()).add(pcode)

    return _ok([_user_row(u, include_roles=True, include_perms=True, perm_cache=perm_cache) for u in items],
               page=page, size=size, total=total)
