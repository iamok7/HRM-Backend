from flask import Blueprint
from flask_jwt_extended import jwt_required, get_jwt_identity
from hrms_api.common.http import ok
from hrms_api.models.user import User
from hrms_api.models.security import user_permission_codes

bp = Blueprint("security", __name__, url_prefix="/api/v1/security")

@bp.get("/me-permissions")
@jwt_required()
def me_permissions():
    uid = get_jwt_identity()
    u = User.query.get(uid)
    roles = [ur.role.code for ur in getattr(u, "user_roles", [])]
    perms = sorted(list(user_permission_codes(uid)))
    return ok({"user": getattr(u, "email", u.id), "roles": roles, "perms": perms})
